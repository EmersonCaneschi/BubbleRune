#!/bin/sh
echo -ne '\033c\033]0;BubbleRune\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/BubbleRuneBeta3.x86_64" "$@"
