Se o computador não conter placa Gráfica ou a integrada não suportar Vulkan para o projeto, aparecerá uma mensagem de erro, para se resolver isto, basta:

1. Entrar no cmd
2. Ir na pasta onde está o executável
	Se não souber: Para Windows por exemplo, onde foi baixado nos downloads:
	1. Ao abrir cmd vai estar em C:\Users\Nome_do_usuario
	2. cd é o comando para entrar na próxima pasta, então seria cd Downloads 
	3. cd BubbleRuneV1Win
	3. Ao extrair o arquivo já estaria
3. Executar o comando: BubbleRuneBeta.x86_64" --rendering-driver opengl3